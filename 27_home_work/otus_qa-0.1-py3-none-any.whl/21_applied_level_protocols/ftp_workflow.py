def test_ftp(ssh_client):
    res = exec_command(ssh_client, 'pwd')
    # устанавливаем ftp сервер, если уже установлен, команда не вернет ошибку
    exec_command(ssh_client, 'sudo apt-get -y install vsftpd')


def exec_command(client, cmd: str) -> str:
    stdin, stdout, stderr = client.exec_command(cmd)
    data = stdout.read() + stderr.read()
    return data.decode('utf-8')


def exec_command_quiet(client, cmd: str):
    client.exec_command(cmd)
