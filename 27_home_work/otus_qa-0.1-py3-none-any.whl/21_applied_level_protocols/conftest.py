import paramiko
import pytest

host = 'localhost'
user = 'anna'
port = 4022


@pytest.fixture(scope="session")
def ssh_client(request):
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    client.connect(hostname=host, username=user, port=port)
    yield client
    client.close()
