from openCart.pages.LoginPage import LoginPage
from openCart.pages.CatalogPage import CatalogPage
from openCart.pages.AccountPage import AccountPage
from openCart.pages.MainPage import MainPage
from openCart.pages.DownloadPage import DownloadPage
from openCart.pages.CustomerPage import CustomerPage