from .MainLocators import MainLocators
from .ProductCartLocators import ProductCartLocators
from .LoginLocators import LoginLocators
from .CatalogProductLocators import CatalogProductLocators
from .AccountLocations import AccountLocations
from .DownLoadLocators import DownLoadLocators
from .CustomerLocators import CustomerLocations
